﻿using Agenda.Datos;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Agenda.Negocio
{
    public class Agendas
    {
        public string Dni { get; set; }
        public string Apellido { get; set; }
        public string Nombre { get; set; }
        public string Calle { get; set; }
        public string Depto { get; set; }
        public int Piso { get; set; }
        public string Ciudad { get; set; }
        public int Telefono { get; set; }
        public string Email { get; set; }
    }

    public class AgendaNegocio
    {
        private AgendaDatos _datos = new AgendaDatos();

        public Agendas ObtenerPorDni(string dni)
        {
            if (string.IsNullOrEmpty(dni)) return null;

            var resultado = _datos.BuscarPorDni(dni);

            if (resultado == null) return null;
            return new Agendas
            {
                Dni = resultado.Value.Dni,
                Apellido = resultado.Value.Apellido,
                Nombre = resultado.Value.Nombre,
                Calle = resultado.Value.Calle,
                Depto = resultado.Value.Depto,
                Piso = resultado.Value.Piso,
                Ciudad = resultado.Value.Ciudad,
                Telefono = resultado.Value.Telefono,
                Email = resultado.Value.Email
            };
        }

        public Agendas ObtenerPorApellido(string apellido)
        {
            if (string.IsNullOrEmpty(apellido)) return null;

            var resultado = _datos.BuscarPorApellido(apellido);

            if (resultado == null) return null;
            return new Agendas
            {
                Dni = resultado.Value.Dni,
                Apellido = resultado.Value.Apellido,
                Nombre = resultado.Value.Nombre,
                Calle = resultado.Value.Calle,
                Depto = resultado.Value.Depto,
                Piso = resultado.Value.Piso,
                Ciudad = resultado.Value.Ciudad,
                Telefono = resultado.Value.Telefono,
                Email = resultado.Value.Email
            };
        }

        public Agendas ObtenerPorNombre(string nombre)
        {
            if (string.IsNullOrEmpty(nombre)) return null;

            var resultado = _datos.BuscarPorNombre(nombre);

            if (resultado == null) return null;
            return new Agendas
            {
                Dni = resultado.Value.Dni,
                Apellido = resultado.Value.Apellido,
                Nombre = resultado.Value.Nombre,
                Calle = resultado.Value.Calle,
                Depto = resultado.Value.Depto,
                Piso = resultado.Value.Piso,
                Ciudad = resultado.Value.Ciudad,
                Telefono = resultado.Value.Telefono,
                Email = resultado.Value.Email
            };
        }

        public Agendas ObtenerPorCalle(string calle)
        {
            if (string.IsNullOrEmpty(calle)) return null;

            var resultado = _datos.BuscarPorCalle(calle);

            if (resultado == null) return null;
            return new Agendas
            {
                Dni = resultado.Value.Dni,
                Apellido = resultado.Value.Apellido,
                Nombre = resultado.Value.Nombre,
                Calle = resultado.Value.Calle,
                Depto = resultado.Value.Depto,
                Piso = resultado.Value.Piso,
                Ciudad = resultado.Value.Ciudad,
                Telefono = resultado.Value.Telefono,
                Email = resultado.Value.Email
            };
        }

        public bool AgregarAgenda(Agendas agenda)
        {
            if (agenda == null) return false;
            if (string.IsNullOrWhiteSpace(agenda.Dni) || string.IsNullOrWhiteSpace(agenda.Nombre)) return false;

            if (_datos.BuscarPorDni(agenda.Dni) != null) return false;

            return _datos.Agregar(agenda.Dni, agenda.Apellido, agenda.Nombre, agenda.Calle, agenda.Depto, agenda.Piso, agenda.Ciudad, agenda.Telefono, agenda.Email);
        }

        public bool ModificarAgenda(Agendas agenda)
        {
            if (agenda == null) return false;
            if (string.IsNullOrWhiteSpace(agenda.Dni) || string.IsNullOrWhiteSpace(agenda.Nombre)) return false;

            return _datos.Modificar(agenda.Dni, agenda.Apellido, agenda.Nombre, agenda.Calle, agenda.Depto, agenda.Piso, agenda.Ciudad, agenda.Telefono, agenda.Email);
        }

        public bool EliminarAgenda(string agenda)
        {
            if (string.IsNullOrWhiteSpace(agenda)) return false;

            return _datos.Eliminar(agenda);
        }

    }
}