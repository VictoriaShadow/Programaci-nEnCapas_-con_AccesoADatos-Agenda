﻿using Agenda.Negocio;
using System;
using static System.Runtime.InteropServices.JavaScript.JSType;

public class Program
{
    public static void Main()
    {
        AgendaNegocio negocio = new AgendaNegocio();
        int opcion;

        do
        {
            Console.Clear();
            Console.WriteLine("===== MENÚ =====");
            Console.WriteLine("1. Agregar agenda");
            Console.WriteLine("2. Modificar agenda");
            Console.WriteLine("3. Eliminar agenda");
            Console.WriteLine("4. Buscar agenda por DNI");
            Console.WriteLine("5. Buscar agenda por Apellido");
            Console.WriteLine("6. Buscar agenda por Nombre");
            Console.WriteLine("7. Buscar agenda por Calle");
            Console.WriteLine("8. Salir");
            Console.Write("Seleccione una opción: ");

            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.WriteLine("===== Agregar producto =====");

                    Console.Write("Ingrese DNI de nueva agenda: ");
                    string dniA = Console.ReadLine();
                    Console.Write("Ingrese apellido de nueva agenda: ");
                    string apellidoA = Console.ReadLine();
                    Console.Write("Ingrese nombre de nueva agenda: ");
                    string nombreA = Console.ReadLine();
                    Console.Write("Ingrese calle de nueva agenda: ");
                    string calleA = Console.ReadLine();
                    Console.Write("Ingrese depto de nueva agenda: ");
                    string deptoA = Console.ReadLine();
                    Console.Write("Ingrese piso de nueva agenda: ");
                    int pisoA = int.Parse(Console.ReadLine());
                    Console.Write("Ingrese ciudad de nueva agenda: ");
                    string ciudadA = Console.ReadLine();
                    Console.Write("Ingrese nuevo teléfono: ");
                    int telefonoA = int.Parse(Console.ReadLine());
                    Console.Write("Ingrese email de nueva agenda: ");
                    string emailA = Console.ReadLine();

                    Agendas agendaNueva = new Agendas();
                    agendaNueva.Dni = dniA;
                    agendaNueva.Apellido = apellidoA;
                    agendaNueva.Nombre = nombreA;
                    agendaNueva.Calle = calleA;
                    agendaNueva.Depto = deptoA;
                    agendaNueva.Piso = pisoA;
                    agendaNueva.Ciudad = ciudadA;
                    agendaNueva.Telefono = telefonoA;
                    agendaNueva.Email = emailA;

                    bool agregado = negocio.AgregarAgenda(agendaNueva);

                    if (agregado)
                    {
                        Console.WriteLine("Agenda agregada.");
                    }
                    else
                    {
                        Console.WriteLine("No se ha podido agregar.");
                    }

                    break;

                case 2:
                    Console.WriteLine("===== Modificar producto =====");
                    Console.Write("Ingrese el DNI: ");
                    string dniM = Console.ReadLine();

                    Console.Write("Ingrese nuevo apellido: ");
                    string apellidoM = Console.ReadLine();

                    Console.Write("Ingrese nuevo nombre: ");
                    string nombreM = Console.ReadLine();

                    Console.Write("Ingrese el calle: ");
                    string calleM = Console.ReadLine();

                    Console.Write("Ingrese nuevo depto: ");
                    string deptoM = Console.ReadLine();

                    Console.Write("Ingrese nuevo piso: ");
                    int pisoM = int.Parse(Console.ReadLine());

                    Console.Write("Ingrese el ciudad: ");
                    string ciudadM = Console.ReadLine();

                    Console.Write("Ingrese nuevo teléfono: ");
                    int telefonoM = int.Parse(Console.ReadLine());

                    Console.Write("Ingrese nuevo email: ");
                    string emailM = Console.ReadLine();

                    Agendas agendaModificar = new Agendas();
                    agendaModificar.Dni = dniM;
                    agendaModificar.Apellido = apellidoM;
                    agendaModificar.Nombre = nombreM;
                    agendaModificar.Calle = calleM;
                    agendaModificar.Depto = deptoM;
                    agendaModificar.Piso = pisoM;
                    agendaModificar.Ciudad = ciudadM;
                    agendaModificar.Telefono = telefonoM;
                    agendaModificar.Email = emailM;

                    bool modificado = negocio.ModificarAgenda(agendaModificar);

                    if (modificado)
                    {
                        Console.WriteLine("Agenda modificado.");
                    }
                    else
                    {
                        Console.WriteLine("No se ha podido modificar.");
                    }
                    break;

                case 3:

                    Console.WriteLine("===== Eliminar Agenda =====");
                    Console.Write("Ingrese el DNI: ");
                    string dniE = Console.ReadLine();

                    bool eliminado = negocio.EliminarAgenda(dniE);

                    if (eliminado)
                        Console.WriteLine("Agenda eliminada.");
                    else
                        Console.WriteLine("No se ha podido eliminar.");
                    break;

                case 4:
                    Console.WriteLine("===== Buscar Agenda por DNI =====");
                    Console.Write("Ingrese DNI de la agenda: ");
                    string dniB = Console.ReadLine();

                    Agendas agenda4 = negocio.ObtenerPorDni(dniB);

                    if (agenda4 != null)
                        Console.WriteLine($"Encontrado: {agenda4.Dni}, {agenda4.Apellido}, {agenda4.Nombre}, {agenda4.Calle}, {agenda4.Depto}, {agenda4.Piso}, {agenda4.Ciudad}, {agenda4.Telefono}, {agenda4.Email}");
                    else
                        Console.WriteLine("No existe.");
                    break;

                case 5:
                    Console.WriteLine("===== Buscar Agenda por Apellido =====");
                    Console.Write("Ingrese apellido de la agenda: ");
                    string apellidoB = Console.ReadLine();

                    Agendas agenda5 = negocio.ObtenerPorApellido(apellidoB);

                    if (agenda5 != null)
                        Console.WriteLine($"Encontrado: {agenda5.Dni}, {agenda5.Apellido}, {agenda5.Nombre}, {agenda5.Calle}, {agenda5.Depto}, {agenda5.Piso}, {agenda5.Ciudad}, {agenda5.Telefono}, {agenda5.Email}");
                    else
                        Console.WriteLine("No existe.");
                    break;

                case 6:
                    Console.WriteLine("===== Buscar Agenda por Nombre =====");
                    Console.Write("Ingrese nombre de la agenda: ");
                    string nombreB = Console.ReadLine();

                    Agendas agenda6 = negocio.ObtenerPorNombre(nombreB);

                    if (agenda6 != null)
                        Console.WriteLine($"Encontrado: {agenda6.Dni}, {agenda6.Apellido}, {agenda6.Nombre}, {agenda6.Calle}, {agenda6.Depto}, {agenda6.Piso}, {agenda6.Ciudad}, {agenda6.Telefono}, {agenda6.Email}");
                    else
                        Console.WriteLine("No existe.");
                    break;

                case 7:
                    Console.WriteLine("===== Buscar Agenda por Calle =====");
                    Console.Write("Ingrese código de producto: ");
                    string calleB = Console.ReadLine();

                    Agendas agenda7 = negocio.ObtenerPorCalle(calleB);

                    if (agenda7 != null)
                        Console.WriteLine($"Encontrado: {agenda7.Dni}, {agenda7.Apellido}, {agenda7.Nombre}, {agenda7.Calle}, {agenda7.Depto}, {agenda7.Piso}, {agenda7.Ciudad}, {agenda7.Telefono}, {agenda7.Email}");
                    else
                        Console.WriteLine("No existe.");
                    break;

                case 8:
                    Console.WriteLine("Saliendo...");
                    break;

                default:
                    Console.WriteLine("Opción inválida.");
                    break;
            }

            Console.WriteLine();

        } while (opcion != 8);
    }
}