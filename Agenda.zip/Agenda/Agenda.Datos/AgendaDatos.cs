﻿using MySql.Data.MySqlClient;
using System.Net;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Agenda.Datos
{
    public class AgendaDatos
    {
        private string _conexionString = "Server=localhost;Database=agenda;Uid=root;Pwd=;";

        public (string Dni, string Apellido, string Nombre, string Calle, string Depto, int Piso, string Ciudad, int Telefono, string Email)? BuscarPorDni(string dni)
        {
            string query = "SELECT Dni, Apellido, Nombre, Calle, Depto, Piso, Ciudad, Telefono, Email FROM agenda WHERE dni = @Dni";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Dni", dni);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        string dniDb = reader["Dni"].ToString();
                        string apellidoDb = reader["Apellido"].ToString();
                        string nombreDb = reader["Nombre"].ToString();
                        string calleDb = reader["Calle"].ToString();
                        string deptoDb = reader["Depto"].ToString();
                        int pisoDb = Convert.ToInt32(reader["Piso"]);
                        string ciudadDb = reader["Ciudad"].ToString();
                        int telefonoDb = Convert.ToInt32(reader["Telefono"]);
                        string emailDb = reader["Email"].ToString();

                        return (dniDb, apellidoDb, nombreDb, calleDb, deptoDb, pisoDb, ciudadDb, telefonoDb, emailDb);
                    }
                }
            }

            return null;
        }

        public (string Dni, string Apellido, string Nombre, string Calle, string Depto, int Piso, string Ciudad, int Telefono, string Email)? BuscarPorApellido(string apellido)
        {
            string query = "SELECT Dni, Apellido, Nombre, Calle, Depto, Piso, Ciudad, Telefono, Email FROM agenda WHERE apellido = @Apellido";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Apellido", apellido);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        string dniDb = reader["Dni"].ToString();
                        string apellidoDb = reader["Apellido"].ToString();
                        string nombreDb = reader["Nombre"].ToString();
                        string calleDb = reader["Calle"].ToString();
                        string deptoDb = reader["Depto"].ToString();
                        int pisoDb = Convert.ToInt32(reader["Piso"]);
                        string ciudadDb = reader["Ciudad"].ToString();
                        int telefonoDb = Convert.ToInt32(reader["Telefono"]);
                        string emailDb = reader["Email"].ToString();

                        return (dniDb, apellidoDb, nombreDb, calleDb, deptoDb, pisoDb, ciudadDb, telefonoDb, emailDb);
                    }
                }
            }

            return null;
        }

        public (string Dni, string Apellido, string Nombre, string Calle, string Depto, int Piso, string Ciudad, int Telefono, string Email)? BuscarPorNombre(string nombre)
        {
            string query = "SELECT Dni, Apellido, Nombre, Calle, Depto, Piso, Ciudad, Telefono, Email FROM agenda WHERE nombre = @Nombre";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Nombre", nombre);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        string dniDb = reader["Dni"].ToString();
                        string apellidoDb = reader["Apellido"].ToString();
                        string nombreDb = reader["Nombre"].ToString();
                        string calleDb = reader["Calle"].ToString();
                        string deptoDb = reader["Depto"].ToString();
                        int pisoDb = Convert.ToInt32(reader["Piso"]);
                        string ciudadDb = reader["Ciudad"].ToString();
                        int telefonoDb = Convert.ToInt32(reader["Telefono"]);
                        string emailDb = reader["Email"].ToString();

                        return (dniDb, apellidoDb, nombreDb, calleDb, deptoDb, pisoDb, ciudadDb, telefonoDb, emailDb);
                    }
                }
            }

            return null;
        }

        public (string Dni, string Apellido, string Nombre, string Calle, string Depto, int Piso, string Ciudad, int Telefono, string Email)? BuscarPorCalle(string calle)
        {
            string query = "SELECT Dni, Apellido, Nombre, Calle, Depto, Piso, Ciudad, Telefono, Email FROM agenda WHERE calle = @Calle";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Calle", calle);

                conexion.Open();

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        string dniDb = reader["Dni"].ToString();
                        string apellidoDb = reader["Apellido"].ToString();
                        string nombreDb = reader["Nombre"].ToString();
                        string calleDb = reader["Calle"].ToString();
                        string deptoDb = reader["Depto"].ToString();
                        int pisoDb = Convert.ToInt32(reader["Piso"]);
                        string ciudadDb = reader["Ciudad"].ToString();
                        int telefonoDb = Convert.ToInt32(reader["Telefono"]);
                        string emailDb = reader["Email"].ToString();

                        return (dniDb, apellidoDb, nombreDb, calleDb, deptoDb, pisoDb, ciudadDb, telefonoDb, emailDb);
                    }
                }
            }

            return null;
        }

        public bool Agregar(string dni, string apellido, string nombre, string calle, string depto, int piso, string ciudad, int telefono, string email)
        {
            string query = "INSERT INTO agenda(Dni, Apellido, Nombre, Calle, Depto, Piso, Ciudad, Telefono, Email) VALUES (@Dni, @Apellido, @Nombre, @Calle, @Depto, @Piso, @Ciudad, @Telefono, @Email)";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Dni", dni);
                comando.Parameters.AddWithValue("@Apellido", apellido);
                comando.Parameters.AddWithValue("@Nombre", nombre);
                comando.Parameters.AddWithValue("@Calle", calle);
                comando.Parameters.AddWithValue("@Depto", depto);
                comando.Parameters.AddWithValue("@Piso", piso);
                comando.Parameters.AddWithValue("@Ciudad", ciudad);
                comando.Parameters.AddWithValue("@Telefono", telefono);
                comando.Parameters.AddWithValue("@Email", email);

                conexion.Open();

                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0;
            }
        }

        public bool Modificar(string Dni, string nuevoApellido, string nuevoNombre, string nuevoCalle, string nuevoDepto, int nuevoPiso, string nuevoCiudad, int nuevoTelefono, string nuevoEmail)
        {
            string query = "UPDATE agenda SET Apellido = @Apellido, Nombre = @Nombre, Calle = @Calle, Depto = @Depto, Piso = @Piso, Ciudad = @Ciudad, Telefono = @Telefono, Email = @Email WHERE Dni = @Dni";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Dni", Dni);
                comando.Parameters.AddWithValue("@Apellido", nuevoApellido);
                comando.Parameters.AddWithValue("@Nombre", nuevoNombre);
                comando.Parameters.AddWithValue("@Calle", nuevoCalle);
                comando.Parameters.AddWithValue("@Depto", nuevoDepto);
                comando.Parameters.AddWithValue("@Piso", nuevoPiso);
                comando.Parameters.AddWithValue("@Ciudad", nuevoCiudad);
                comando.Parameters.AddWithValue("@Telefono", nuevoTelefono);
                comando.Parameters.AddWithValue("@Email", nuevoEmail);

                conexion.Open();

                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0;
            }
        }

        public bool Eliminar(string dni)
        {
            string query = "DELETE FROM agenda WHERE dni = @Dni";

            using (MySqlConnection conexion = new MySqlConnection(_conexionString))
            {
                MySqlCommand comando = new MySqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Dni", dni);

                conexion.Open();

                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0;
            }
        }
    }
}